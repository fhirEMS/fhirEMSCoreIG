# EMS Age Units - FHIR EMS Core Implementation Guide (Unofficial Research Project) v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EMS Age Units**

## ValueSet: EMS Age Units 

| | |
| :--- | :--- |
| *Official URL*:https://fhirems.github.io/fhirEMSCoreIG/ValueSet/vs-ems-age-units | *Version*:0.2.0 |
| Active as of 2026-07-19 | *Computable Name*:EMSAgeUnitsVS |
| *Other Identifiers:*OID:2.25.219926138944530828037824748808947630693.2.5 | |

 
NEMSIS ePatient.16 - Units of measure for the patient's age when exact date of birth is unknown. Used alongside ePatient.15 (Age). 

 **References** 

* [EMS Patient Estimated Age](StructureDefinition-ext-ems-patient-age.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "vs-ems-age-units",
  "url" : "https://fhirems.github.io/fhirEMSCoreIG/ValueSet/vs-ems-age-units",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.25.219926138944530828037824748808947630693.2.5"
  }],
  "version" : "0.2.0",
  "name" : "EMSAgeUnitsVS",
  "title" : "EMS Age Units",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-19T20:45:43-04:00",
  "publisher" : "fhirEMSCore Research Project (AI-Generated — Unofficial)",
  "contact" : [{
    "name" : "fhirEMSCore Research Project (AI-Generated — Unofficial)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/fhirEMS/fhirEMSCoreIG"
    }]
  },
  {
    "name" : "fhirEMSCore Research Project",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/fhirEMS/fhirEMSCoreIG"
    }]
  }],
  "description" : "NEMSIS ePatient.16 - Units of measure for the patient's age when exact date of birth is unknown. Used alongside ePatient.15 (Age).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "US",
      "display" : "United States of America"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://fhirems.github.io/fhirEMSCoreIG/CodeSystem/nemsis-patient",
      "concept" : [{
        "code" : "2516001",
        "display" : "Days"
      },
      {
        "code" : "2516003",
        "display" : "Hours"
      },
      {
        "code" : "2516005",
        "display" : "Minutes"
      },
      {
        "code" : "2516007",
        "display" : "Months"
      },
      {
        "code" : "2516009",
        "display" : "Years"
      }]
    }]
  }
}

```
