# EMS Type of Transport Delay - FHIR EMS Core Implementation Guide (Unofficial Research Project) v0.2.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EMS Type of Transport Delay**

## ValueSet: EMS Type of Transport Delay 

| | |
| :--- | :--- |
| *Official URL*:https://fhirems.github.io/fhirEMSCoreIG/ValueSet/vs-ems-transport-delay | *Version*:0.2.0 |
| Active as of 2026-07-19 | *Computable Name*:EMSTransportDelayVS |
| *Other Identifiers:*OID:2.25.219926138944530828037824748808947630693.2.119 | |

 
NEMSIS eResponse.11 - Types of delay during transport. 

 **References** 

* [EMS Response Delays](StructureDefinition-ext-ems-response-delays.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "vs-ems-transport-delay",
  "url" : "https://fhirems.github.io/fhirEMSCoreIG/ValueSet/vs-ems-transport-delay",
  "identifier" : [{
    "system" : "urn:ietf:rfc:3986",
    "value" : "urn:oid:2.25.219926138944530828037824748808947630693.2.119"
  }],
  "version" : "0.2.0",
  "name" : "EMSTransportDelayVS",
  "title" : "EMS Type of Transport Delay",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-19T20:45:43-04:00",
  "publisher" : "fhirEMSCore Research Project (AI-Generated — Unofficial)",
  "contact" : [{
    "name" : "fhirEMSCore Research Project (AI-Generated — Unofficial)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/fhirEMS/fhirEMSCoreIG"
    }]
  },
  {
    "name" : "fhirEMSCore Research Project",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/fhirEMS/fhirEMSCoreIG"
    }]
  }],
  "description" : "NEMSIS eResponse.11 - Types of delay during transport.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "US",
      "display" : "United States of America"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://fhirems.github.io/fhirEMSCoreIG/CodeSystem/cs-nemsis-encounter",
      "concept" : [{
        "code" : "2211001",
        "display" : "Crowd"
      },
      {
        "code" : "2211003",
        "display" : "Directions/Unable to Locate"
      },
      {
        "code" : "2211005",
        "display" : "Distance"
      },
      {
        "code" : "2211007",
        "display" : "Diversion"
      },
      {
        "code" : "2211009",
        "display" : "HazMat"
      },
      {
        "code" : "2211011",
        "display" : "None/No Delay"
      },
      {
        "code" : "2211013",
        "display" : "Other"
      },
      {
        "code" : "2211015",
        "display" : "Rendezvous Transport Unavailable"
      },
      {
        "code" : "2211017",
        "display" : "Route Obstruction (e.g., Train)"
      },
      {
        "code" : "2211019",
        "display" : "Safety"
      },
      {
        "code" : "2211021",
        "display" : "Staff Delay"
      },
      {
        "code" : "2211023",
        "display" : "Traffic"
      },
      {
        "code" : "2211025",
        "display" : "Vehicle Crash Involving this Unit"
      },
      {
        "code" : "2211027",
        "display" : "Vehicle Failure of this Unit"
      },
      {
        "code" : "2211029",
        "display" : "Weather"
      },
      {
        "code" : "2211031",
        "display" : "Patient Condition Change (e.g., Unit Stopped)"
      }]
    }]
  }
}

```
